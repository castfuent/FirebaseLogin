package com.example.firebaselogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText user;
    Button botonLogin,botonRegistrar;
    EditText password;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user=(EditText)findViewById(R.id.editTextLogin);
        password=(EditText)findViewById(R.id.editTextPassword);
        botonLogin=(Button)findViewById(R.id.botonAceptar);
        botonRegistrar=(Button)findViewById(R.id.botonRegistrar);

        botonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Login",Toast.LENGTH_SHORT).show();
            }
        });

        botonRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,"Registro",Toast.LENGTH_SHORT).show();

            }
        });


    }
}